<#
.SYNOPSIS
    Bulk provisions Active Directory users from a CSV file.
.DESCRIPTION
    Reads a CSV file containing user information and creates AD user accounts
    with proper OU placement, group membership, and password assignment.
    Includes error handling, logging, and CSV export of results.
.PARAMETER CSVPath
    Path to the CSV file containing user data.
.PARAMETER DefaultPassword
    Default password assigned to new accounts. Users will be forced to change at first login.
.PARAMETER LogPath
    Path for the output log file. Defaults to current directory.
.EXAMPLE
    .\New-BulkADUsers.ps1 -CSVPath "C:\Users\Admin\Desktop\NewHires.csv"
.EXAMPLE
    .\New-BulkADUsers.ps1 -CSVPath ".\NewHires.csv" -DefaultPassword "Welcome2025!" -LogPath "C:\Logs"
.NOTES
    Author: Elazar Ferrer
    Date: 2024
    Requires: ActiveDirectory PowerShell module, Domain Admin privileges
    CSV Headers Required: FirstName, LastName, Department, Title, OU
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory = $true, HelpMessage = "Path to the CSV file containing user data")]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [string]$CSVPath,

    [Parameter(Mandatory = $false)]
    [string]$DefaultPassword = "Welcome2025!",

    [Parameter(Mandatory = $false)]
    [string]$LogPath = (Get-Location).Path
)

# ============================================================
# CONFIGURATION
# ============================================================
$DomainSuffix = "@ferrerlab.local"
$BaseDN       = "DC=ferrerlab,DC=local"
$Date         = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$LogFile      = Join-Path $LogPath "BulkUserCreation_$Date.log"
$ResultsCSV   = Join-Path $LogPath "BulkUserCreation_Results_$Date.csv"

# ============================================================
# FUNCTIONS
# ============================================================
function Write-Log {
    param (
        [string]$Message,
        [ValidateSet("INFO", "WARN", "ERROR", "SUCCESS")]
        [string]$Level = "INFO"
    )
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry  = "[$Timestamp] [$Level] $Message"
    Add-Content -Path $LogFile -Value $LogEntry
    switch ($Level) {
        "ERROR"   { Write-Host $LogEntry -ForegroundColor Red }
        "WARN"    { Write-Host $LogEntry -ForegroundColor Yellow }
        "SUCCESS" { Write-Host $LogEntry -ForegroundColor Green }
        default   { Write-Host $LogEntry -ForegroundColor Cyan }
    }
}

function New-SAMAccountName {
    param (
        [string]$FirstName,
        [string]$LastName
    )
    # Format: first initial + last name (e.g., eferrer)
    $SAM = ($FirstName.Substring(0, 1) + $LastName).ToLower() -replace '[^a-z0-9]', ''
    # Truncate to 20 characters (SAM limit)
    if ($SAM.Length -gt 20) { $SAM = $SAM.Substring(0, 20) }
    return $SAM
}

function Test-OUExists {
    param ([string]$OUPath)
    try {
        Get-ADOrganizationalUnit -Identity $OUPath -ErrorAction Stop | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

# ============================================================
# MAIN SCRIPT
# ============================================================
Write-Log "====== Bulk AD User Provisioning Started ======"
Write-Log "CSV Source: $CSVPath"
Write-Log "Domain: ferrerlab.local"

# Import Active Directory module
try {
    Import-Module ActiveDirectory -ErrorAction Stop
    Write-Log "Active Directory module loaded successfully."
}
catch {
    Write-Log "Failed to load Active Directory module: $_" -Level "ERROR"
    exit 1
}

# Import and validate CSV
try {
    $Users = Import-Csv -Path $CSVPath -ErrorAction Stop
    $RequiredHeaders = @("FirstName", "LastName", "Department", "Title", "OU")
    $CSVHeaders = ($Users | Get-Member -MemberType NoteProperty).Name

    foreach ($Header in $RequiredHeaders) {
        if ($Header -notin $CSVHeaders) {
            Write-Log "Missing required CSV column: $Header" -Level "ERROR"
            exit 1
        }
    }
    Write-Log "CSV imported successfully. Found $($Users.Count) user(s) to process."
}
catch {
    Write-Log "Failed to import CSV: $_" -Level "ERROR"
    exit 1
}

# Process each user
$Results      = @()
$SuccessCount = 0
$FailCount    = 0
$SkipCount    = 0

foreach ($User in $Users) {
    $FirstName  = $User.FirstName.Trim()
    $LastName   = $User.LastName.Trim()
    $Department = $User.Department.Trim()
    $Title      = $User.Title.Trim()
    $OUName     = $User.OU.Trim()

    $SAM         = New-SAMAccountName -FirstName $FirstName -LastName $LastName
    $UPN         = "$SAM$DomainSuffix"
    $DisplayName = "$FirstName $LastName"
    $OUPath      = "OU=$OUName,$BaseDN"

    $Result = [PSCustomObject]@{
        FirstName   = $FirstName
        LastName    = $LastName
        SAMAccount  = $SAM
        UPN         = $UPN
        Department  = $Department
        Title       = $Title
        OU          = $OUPath
        Status      = ""
        ErrorDetail = ""
    }

    # Check if user already exists
    try {
        $ExistingUser = Get-ADUser -Filter "SamAccountName -eq '$SAM'" -ErrorAction Stop
        if ($ExistingUser) {
            Write-Log "SKIPPED: User '$SAM' already exists in AD." -Level "WARN"
            $Result.Status      = "SKIPPED"
            $Result.ErrorDetail = "User already exists"
            $SkipCount++
            $Results += $Result
            continue
        }
    }
    catch {
        # User does not exist — proceed with creation
    }

    # Verify OU exists
    if (-not (Test-OUExists -OUPath $OUPath)) {
        Write-Log "OU does not exist: $OUPath — Skipping user $SAM" -Level "ERROR"
        $Result.Status      = "FAILED"
        $Result.ErrorDetail = "OU not found: $OUPath"
        $FailCount++
        $Results += $Result
        continue
    }

    # Create the user account
    try {
        $SecurePassword = ConvertTo-SecureString $DefaultPassword -AsPlainText -Force

        $NewUserParams = @{
            SamAccountName        = $SAM
            UserPrincipalName     = $UPN
            Name                  = $DisplayName
            GivenName             = $FirstName
            Surname               = $LastName
            DisplayName           = $DisplayName
            Department            = $Department
            Title                 = $Title
            Path                  = $OUPath
            AccountPassword       = $SecurePassword
            Enabled               = $true
            ChangePasswordAtLogon = $true
            PasswordNeverExpires  = $false
            ErrorAction           = "Stop"
        }

        New-ADUser @NewUserParams
        Write-Log "SUCCESS: Created user '$SAM' in $OUPath" -Level "SUCCESS"
        $Result.Status = "CREATED"
        $SuccessCount++
    }
    catch {
        Write-Log "FAILED: Could not create user '$SAM': $_" -Level "ERROR"
        $Result.Status      = "FAILED"
        $Result.ErrorDetail = $_.Exception.Message
        $FailCount++
    }

    $Results += $Result
}

# ============================================================
# EXPORT RESULTS
# ============================================================
$Results | Export-Csv -Path $ResultsCSV -NoTypeInformation -Encoding UTF8
Write-Log "====== Provisioning Complete ======"
Write-Log "Created: $SuccessCount | Skipped: $SkipCount | Failed: $FailCount"
Write-Log "Results exported to: $ResultsCSV"
Write-Log "Log file: $LogFile"
