<#
.SYNOPSIS
    Reports on inactive Active Directory user accounts.
.DESCRIPTION
    Identifies AD accounts that have not logged in within a specified number of days,
    disabled accounts, and accounts with expired passwords. Exports results to CSV
    with detailed account information for audit and compliance purposes.
.PARAMETER InactiveDays
    Number of days since last login to consider an account inactive. Default: 90
.PARAMETER IncludeDisabled
    Include disabled accounts in the report.
.PARAMETER ExportPath
    Path for the exported CSV report. Defaults to current directory.
.EXAMPLE
    .\Get-InactiveADAccounts.ps1 -InactiveDays 90
.EXAMPLE
    .\Get-InactiveADAccounts.ps1 -InactiveDays 60 -IncludeDisabled -ExportPath "C:\Reports"
.NOTES
    Author: Elazar Ferrer
    Date: 2024
    Requires: ActiveDirectory PowerShell module
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory = $false)]
    [int]$InactiveDays = 90,

    [Parameter(Mandatory = $false)]
    [switch]$IncludeDisabled,

    [Parameter(Mandatory = $false)]
    [string]$ExportPath = (Get-Location).Path
)

# ============================================================
# CONFIGURATION
# ============================================================
$Date           = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$CutoffDate     = (Get-Date).AddDays(-$InactiveDays)
$ReportFile     = Join-Path $ExportPath "InactiveAccounts_Report_$Date.csv"
$SummaryFile    = Join-Path $ExportPath "InactiveAccounts_Summary_$Date.txt"

# ============================================================
# FUNCTIONS
# ============================================================
function Get-AccountStatus {
    param ([Microsoft.ActiveDirectory.Management.ADUser]$User)
    $StatusFlags = @()
    if (-not $User.Enabled)                          { $StatusFlags += "Disabled" }
    if ($User.LockedOut)                              { $StatusFlags += "Locked Out" }
    if ($User.PasswordExpired)                        { $StatusFlags += "Password Expired" }
    if ($User.PasswordNeverExpires)                   { $StatusFlags += "Password Never Expires" }
    if ($null -eq $User.LastLogonDate)                { $StatusFlags += "Never Logged In" }
    elseif ($User.LastLogonDate -lt $CutoffDate)      { $StatusFlags += "Inactive ($InactiveDays+ days)" }
    if ($StatusFlags.Count -eq 0)                     { return "Active" }
    return ($StatusFlags -join "; ")
}

# ============================================================
# MAIN SCRIPT
# ============================================================
Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  Inactive AD Account Report Generator"       -ForegroundColor Cyan
Write-Host "============================================"  -ForegroundColor Cyan
Write-Host "Cutoff Date    : $($CutoffDate.ToString('yyyy-MM-dd'))" -ForegroundColor White
Write-Host "Inactive Days  : $InactiveDays" -ForegroundColor White
Write-Host "Include Disabled: $IncludeDisabled`n" -ForegroundColor White

# Import Active Directory module
try {
    Import-Module ActiveDirectory -ErrorAction Stop
}
catch {
    Write-Host "ERROR: Failed to load Active Directory module: $_" -ForegroundColor Red
    exit 1
}

# ============================================================
# GATHER INACTIVE ACCOUNTS
# ============================================================
Write-Host "Searching for inactive accounts..." -ForegroundColor Yellow

try {
    # Get accounts that haven't logged in since the cutoff date
    $InactiveUsers = Search-ADAccount -AccountInactive -DateTime $CutoffDate -UsersOnly |
        Get-ADUser -Properties DisplayName, Department, Title, LastLogonDate,
                               PasswordLastSet, PasswordExpired, PasswordNeverExpires,
                               Enabled, LockedOut, Created, Description,
                               DistinguishedName, Manager, WhenChanged

    # Get accounts that have NEVER logged in
    $NeverLoggedIn = Get-ADUser -Filter { LastLogonDate -notlike "*" } -Properties `
        DisplayName, Department, Title, LastLogonDate,
        PasswordLastSet, PasswordExpired, PasswordNeverExpires,
        Enabled, LockedOut, Created, Description,
        DistinguishedName, Manager, WhenChanged

    # Combine and deduplicate
    $AllAccounts = @()
    $AllAccounts += $InactiveUsers
    $AllAccounts += $NeverLoggedIn
    $AllAccounts = $AllAccounts | Sort-Object SamAccountName -Unique

    # Filter out disabled if not requested
    if (-not $IncludeDisabled) {
        $AllAccounts = $AllAccounts | Where-Object { $_.Enabled -eq $true }
    }

    Write-Host "Found $($AllAccounts.Count) account(s) matching criteria.`n" -ForegroundColor Green
}
catch {
    Write-Host "ERROR: Failed to query Active Directory: $_" -ForegroundColor Red
    exit 1
}

# ============================================================
# BUILD REPORT
# ============================================================
$Report = @()

foreach ($Account in $AllAccounts) {
    # Calculate days since last login
    if ($null -ne $Account.LastLogonDate) {
        $DaysSinceLogin = (New-TimeSpan -Start $Account.LastLogonDate -End (Get-Date)).Days
    }
    else {
        $DaysSinceLogin = "Never"
    }

    # Calculate days since password change
    if ($null -ne $Account.PasswordLastSet) {
        $DaysSincePasswordChange = (New-TimeSpan -Start $Account.PasswordLastSet -End (Get-Date)).Days
    }
    else {
        $DaysSincePasswordChange = "Never"
    }

    # Get the OU from the Distinguished Name
    $OUPath = ($Account.DistinguishedName -split ",", 2)[1]

    # Resolve manager name
    $ManagerName = ""
    if ($Account.Manager) {
        try {
            $ManagerName = (Get-ADUser $Account.Manager -Properties DisplayName).DisplayName
        }
        catch { $ManagerName = "Unknown" }
    }

    $Report += [PSCustomObject]@{
        SamAccountName           = $Account.SamAccountName
        DisplayName              = $Account.DisplayName
        Department               = $Account.Department
        Title                    = $Account.Title
        Enabled                  = $Account.Enabled
        AccountStatus            = Get-AccountStatus -User $Account
        LastLogonDate            = $Account.LastLogonDate
        DaysSinceLastLogin       = $DaysSinceLogin
        PasswordLastSet          = $Account.PasswordLastSet
        DaysSincePasswordChange  = $DaysSincePasswordChange
        PasswordExpired          = $Account.PasswordExpired
        PasswordNeverExpires     = $Account.PasswordNeverExpires
        LockedOut                = $Account.LockedOut
        AccountCreated           = $Account.Created
        LastModified             = $Account.WhenChanged
        Manager                  = $ManagerName
        OrganizationalUnit       = $OUPath
        Description              = $Account.Description
    }
}

# ============================================================
# EXPORT RESULTS
# ============================================================
$Report | Sort-Object DaysSinceLastLogin -Descending |
    Export-Csv -Path $ReportFile -NoTypeInformation -Encoding UTF8

# ============================================================
# GENERATE SUMMARY
# ============================================================
$TotalInactive       = ($Report | Where-Object { $_.AccountStatus -match "Inactive" }).Count
$TotalNeverLoggedIn  = ($Report | Where-Object { $_.AccountStatus -match "Never Logged In" }).Count
$TotalDisabled       = ($Report | Where-Object { $_.Enabled -eq $false }).Count
$TotalLockedOut      = ($Report | Where-Object { $_.LockedOut -eq $true }).Count
$TotalPwdExpired     = ($Report | Where-Object { $_.PasswordExpired -eq $true }).Count
$TotalPwdNeverExpire = ($Report | Where-Object { $_.PasswordNeverExpires -eq $true }).Count

$Summary = @"
============================================
  INACTIVE AD ACCOUNT REPORT SUMMARY
  Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
============================================

Total Accounts Found       : $($Report.Count)
Inactive ($InactiveDays+ days)  : $TotalInactive
Never Logged In            : $TotalNeverLoggedIn
Disabled Accounts          : $TotalDisabled
Locked Out                 : $TotalLockedOut
Password Expired           : $TotalPwdExpired
Password Never Expires     : $TotalPwdNeverExpire

--- By Department ---
$( ($Report | Group-Object Department | Sort-Object Count -Descending | ForEach-Object { "  $($_.Name): $($_.Count)" }) -join "`n" )

Report exported to: $ReportFile
"@

$Summary | Out-File -FilePath $SummaryFile -Encoding UTF8
Write-Host $Summary -ForegroundColor White
Write-Host "`nFiles exported:" -ForegroundColor Green
Write-Host "  Report : $ReportFile" -ForegroundColor Green
Write-Host "  Summary: $SummaryFile`n" -ForegroundColor Green
