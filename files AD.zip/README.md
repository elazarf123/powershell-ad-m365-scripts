# Active Directory Home Lab — Windows Server 2019, PKI & M365

Enterprise Active Directory lab environment built for hands-on practice with identity administration, Group Policy, PKI, PowerShell automation, and Microsoft 365 hybrid identity.

## Lab Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Hyper-V / VirtualBox                │
│                                                     │
│  ┌──────────────┐   ┌──────────────┐               │
│  │  DC01         │   │  CLIENT01    │               │
│  │  Win Server   │   │  Windows 10  │               │
│  │  2019         │   │  Pro         │               │
│  │              │   │              │               │
│  │  AD DS       │   │  Domain-     │               │
│  │  DNS/DHCP    │   │  Joined      │               │
│  │  PKI (AD CS) │   │  Workstation │               │
│  │  GP Mgmt     │   │              │               │
│  └──────┬───────┘   └──────┬───────┘               │
│         │    Internal Network     │                  │
│         │    10.0.0.0/24          │                  │
│         └────────┬────────────────┘                  │
│                  │                                   │
│  ┌──────────────────────────────┐                   │
│  │  M365 Developer Tenant       │                   │
│  │  Entra ID / Exchange Online  │                   │
│  │  Conditional Access          │                   │
│  │  SPF/DKIM/DMARC             │                   │
│  └──────────────────────────────┘                   │
└─────────────────────────────────────────────────────┘
```

**Domain:** `ferrerlab.local`  
**DC IP:** `10.0.0.10`  
**DHCP Range:** `10.0.0.100 – 10.0.0.200`  
**Subnet Mask:** `255.255.255.0`

## What's Covered

- **Active Directory Domain Services (AD DS):** Forest/domain creation, multi-OU structure, user/group/computer management
- **DNS & DHCP:** Forward/reverse lookup zones, DHCP scope and reservations
- **Group Policy (GPO):** Password policy, software restriction, desktop lockdown, LSDOU precedence, security filtering
- **PKI / Certificate Services:** Enterprise Root CA via AD CS, LDAPS (port 636), certificate templates
- **PowerShell Automation:** Bulk user provisioning, inactive account reporting, group membership auditing
- **Microsoft 365:** Exchange Online, Entra ID, Conditional Access, SPF/DKIM/DMARC, Teams policies

## PowerShell Scripts

| Script | Purpose |
|--------|---------|
| `New-BulkADUsers.ps1` | Provisions AD users from CSV with OU placement, error handling, and result logging |
| `Get-InactiveADAccounts.ps1` | Identifies accounts inactive for 90+ days, never-logged-in accounts, and expired passwords |
| `Get-ADGroupAudit.ps1` | Audits group memberships including nested groups, privileged group members, and empty groups |
| `SampleUsers.csv` | Sample CSV template for bulk provisioning |

### Usage Examples

```powershell
# Bulk provision users from CSV
.\New-BulkADUsers.ps1 -CSVPath ".\SampleUsers.csv"

# Report accounts inactive for 60+ days
.\Get-InactiveADAccounts.ps1 -InactiveDays 60 -IncludeDisabled

# Audit privileged group memberships
.\Get-ADGroupAudit.ps1 -PrivilegedOnly

# Audit a specific group
.\Get-ADGroupAudit.ps1 -GroupName "Domain Admins"
```

## OU Structure

```
ferrerlab.local
├── IT
│   ├── Users
│   ├── Computers
│   └── Service Accounts
├── HR
│   ├── Users
│   └── Computers
├── Finance
│   ├── Users
│   └── Computers
├── Marketing
│   ├── Users
│   └── Computers
├── Security Groups
└── Disabled Accounts
```

## Group Policy Objects

| GPO Name | Scope | Purpose |
|----------|-------|---------|
| Password Policy | Domain | Minimum 12 chars, complexity, 90-day max age, 5 password history |
| Account Lockout | Domain | 5 failed attempts, 30-minute lockout, 30-minute reset |
| Desktop Lockdown | Workstations OU | Remove Control Panel, disable CMD, restrict Settings |
| Software Restriction | Workstations OU | Block executables from user temp/download folders |
| Screen Lock | Domain | 10-minute idle timeout, require password on resume |

## PKI Configuration

- **CA Type:** Enterprise Root CA (AD CS)
- **LDAPS:** Configured on port 636 with auto-enrolled certificates
- **Certificate Templates:** Computer, User, Web Server
- **CRL Distribution:** Published to AD and HTTP

## M365 Developer Tenant

- **Licenses:** 25 x Microsoft 365 E5
- **Entra ID:** User/group management, dynamic groups
- **Exchange Online:** Mailboxes, shared mailboxes, distribution lists
- **Conditional Access:** MFA enforcement, location-based policies, compliant device requirements
- **Email Security:** SPF, DKIM, and DMARC records configured
- **Teams:** Meeting policies, messaging policies, app permissions

## Requirements

- **Host Machine:** 16 GB RAM minimum (32 GB recommended), 100 GB free disk space
- **Hypervisor:** Hyper-V (Windows 10/11 Pro) or VirtualBox (free)
- **ISOs:** Windows Server 2019 Evaluation, Windows 10 Enterprise Evaluation
- **M365:** Microsoft 365 Developer Program (free)

## Setup Guide

A complete step-by-step lab build guide is included in `AD_HomeLab_Setup_Guide.docx`, covering VM creation through M365 integration.

## Author

**Elazar Ferrer**  
Active Directory IT Administrator | M365 | Azure AD / Entra ID | PowerShell  
[LinkedIn](https://linkedin.com/in/elazarf) | ferrerelazar@gmail.com
