<#
.SYNOPSIS
    Audits Active Directory group memberships and exports detailed reports.
.DESCRIPTION
    Generates comprehensive group membership reports for security auditing.
    Identifies nested groups, privileged group members, empty groups, and
    users with excessive group memberships. Exports to CSV for compliance documentation.
.PARAMETER GroupName
    Specific group name to audit. If omitted, audits all groups.
.PARAMETER PrivilegedOnly
    Only audit privileged/admin groups (Domain Admins, Enterprise Admins, etc.)
.PARAMETER ExportPath
    Path for the exported CSV report. Defaults to current directory.
.EXAMPLE
    .\Get-ADGroupAudit.ps1
.EXAMPLE
    .\Get-ADGroupAudit.ps1 -GroupName "Domain Admins"
.EXAMPLE
    .\Get-ADGroupAudit.ps1 -PrivilegedOnly -ExportPath "C:\Audits"
.NOTES
    Author: Elazar Ferrer
    Date: 2024
    Requires: ActiveDirectory PowerShell module
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory = $false)]
    [string]$GroupName,

    [Parameter(Mandatory = $false)]
    [switch]$PrivilegedOnly,

    [Parameter(Mandatory = $false)]
    [string]$ExportPath = (Get-Location).Path
)

# ============================================================
# CONFIGURATION
# ============================================================
$Date = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$MembershipReport = Join-Path $ExportPath "GroupMembership_Report_$Date.csv"
$PrivilegedReport = Join-Path $ExportPath "PrivilegedGroups_Report_$Date.csv"
$SummaryReport    = Join-Path $ExportPath "GroupAudit_Summary_$Date.txt"

$PrivilegedGroups = @(
    "Domain Admins",
    "Enterprise Admins",
    "Schema Admins",
    "Administrators",
    "Account Operators",
    "Backup Operators",
    "Server Operators",
    "Print Operators",
    "DnsAdmins",
    "Group Policy Creator Owners"
)

# ============================================================
# FUNCTIONS
# ============================================================
function Get-GroupMembersRecursive {
    param (
        [string]$GroupDN,
        [string]$ParentGroup = "",
        [int]$Depth = 0
    )

    $Members = @()

    try {
        $GroupMembers = Get-ADGroupMember -Identity $GroupDN -ErrorAction Stop

        foreach ($Member in $GroupMembers) {
            if ($Member.objectClass -eq "group") {
                # Record the nested group itself
                $Members += [PSCustomObject]@{
                    MemberName       = $Member.Name
                    SamAccountName   = $Member.SamAccountName
                    ObjectType       = "Group (Nested)"
                    ParentGroup      = $ParentGroup
                    NestingDepth     = $Depth
                    Enabled          = "N/A"
                    LastLogonDate    = "N/A"
                    Department       = "N/A"
                    Title            = "N/A"
                    DistinguishedName = $Member.DistinguishedName
                }

                # Recurse into nested group (max depth 5 to prevent loops)
                if ($Depth -lt 5) {
                    $NestedMembers = Get-GroupMembersRecursive `
                        -GroupDN $Member.DistinguishedName `
                        -ParentGroup $Member.Name `
                        -Depth ($Depth + 1)
                    $Members += $NestedMembers
                }
            }
            elseif ($Member.objectClass -eq "user") {
                try {
                    $UserDetails = Get-ADUser -Identity $Member.SamAccountName `
                        -Properties DisplayName, Department, Title, LastLogonDate, Enabled

                    $Members += [PSCustomObject]@{
                        MemberName        = $UserDetails.DisplayName
                        SamAccountName    = $UserDetails.SamAccountName
                        ObjectType        = "User"
                        ParentGroup       = $ParentGroup
                        NestingDepth      = $Depth
                        Enabled           = $UserDetails.Enabled
                        LastLogonDate     = $UserDetails.LastLogonDate
                        Department        = $UserDetails.Department
                        Title             = $UserDetails.Title
                        DistinguishedName = $UserDetails.DistinguishedName
                    }
                }
                catch {
                    Write-Host "  WARNING: Could not retrieve details for $($Member.SamAccountName)" -ForegroundColor Yellow
                }
            }
            elseif ($Member.objectClass -eq "computer") {
                $Members += [PSCustomObject]@{
                    MemberName        = $Member.Name
                    SamAccountName    = $Member.SamAccountName
                    ObjectType        = "Computer"
                    ParentGroup       = $ParentGroup
                    NestingDepth      = $Depth
                    Enabled           = "N/A"
                    LastLogonDate     = "N/A"
                    Department        = "N/A"
                    Title             = "N/A"
                    DistinguishedName = $Member.DistinguishedName
                }
            }
        }
    }
    catch {
        Write-Host "  ERROR: Could not enumerate members of group: $_" -ForegroundColor Red
    }

    return $Members
}

# ============================================================
# MAIN SCRIPT
# ============================================================
Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  Active Directory Group Membership Audit"     -ForegroundColor Cyan
Write-Host "============================================`n" -ForegroundColor Cyan

# Import Active Directory module
try {
    Import-Module ActiveDirectory -ErrorAction Stop
}
catch {
    Write-Host "ERROR: Failed to load Active Directory module: $_" -ForegroundColor Red
    exit 1
}

# ============================================================
# DETERMINE WHICH GROUPS TO AUDIT
# ============================================================
if ($GroupName) {
    # Audit a specific group
    try {
        $Groups = @(Get-ADGroup -Identity $GroupName -Properties Description, Created, Modified -ErrorAction Stop)
        Write-Host "Auditing single group: $GroupName" -ForegroundColor Yellow
    }
    catch {
        Write-Host "ERROR: Group '$GroupName' not found: $_" -ForegroundColor Red
        exit 1
    }
}
elseif ($PrivilegedOnly) {
    # Audit only privileged groups
    $Groups = @()
    foreach ($PG in $PrivilegedGroups) {
        try {
            $Groups += Get-ADGroup -Identity $PG -Properties Description, Created, Modified -ErrorAction SilentlyContinue
        }
        catch { }
    }
    Write-Host "Auditing $($Groups.Count) privileged groups." -ForegroundColor Yellow
}
else {
    # Audit all groups
    $Groups = Get-ADGroup -Filter * -Properties Description, Created, Modified
    Write-Host "Auditing all $($Groups.Count) groups in the domain." -ForegroundColor Yellow
}

# ============================================================
# AUDIT EACH GROUP
# ============================================================
$AllMemberships   = @()
$GroupSummaries    = @()
$EmptyGroups       = @()

foreach ($Group in $Groups) {
    Write-Host "  Processing: $($Group.Name)..." -ForegroundColor White -NoNewline

    $Members = Get-GroupMembersRecursive -GroupDN $Group.DistinguishedName -ParentGroup $Group.Name
    $MemberCount = ($Members | Where-Object { $_.ObjectType -eq "User" }).Count

    if ($MemberCount -eq 0) {
        Write-Host " (empty)" -ForegroundColor DarkGray
        $EmptyGroups += $Group.Name
    }
    else {
        Write-Host " ($MemberCount users)" -ForegroundColor Green
    }

    foreach ($Member in $Members) {
        $AllMemberships += [PSCustomObject]@{
            GroupName         = $Group.Name
            GroupScope        = $Group.GroupScope
            GroupCategory     = $Group.GroupCategory
            IsPrivileged      = ($Group.Name -in $PrivilegedGroups)
            MemberName        = $Member.MemberName
            SamAccountName    = $Member.SamAccountName
            ObjectType        = $Member.ObjectType
            NestingDepth      = $Member.NestingDepth
            Enabled           = $Member.Enabled
            LastLogonDate     = $Member.LastLogonDate
            Department        = $Member.Department
            Title             = $Member.Title
            DistinguishedName = $Member.DistinguishedName
        }
    }

    $GroupSummaries += [PSCustomObject]@{
        GroupName    = $Group.Name
        MemberCount  = $MemberCount
        HasNested    = ($Members | Where-Object { $_.ObjectType -eq "Group (Nested)" }).Count -gt 0
        IsPrivileged = ($Group.Name -in $PrivilegedGroups)
        Description  = $Group.Description
        Created      = $Group.Created
    }
}

# ============================================================
# EXPORT FULL MEMBERSHIP REPORT
# ============================================================
$AllMemberships | Export-Csv -Path $MembershipReport -NoTypeInformation -Encoding UTF8

# ============================================================
# EXPORT PRIVILEGED GROUPS REPORT
# ============================================================
$PrivilegedMembers = $AllMemberships | Where-Object { $_.IsPrivileged -eq $true }
if ($PrivilegedMembers.Count -gt 0) {
    $PrivilegedMembers | Export-Csv -Path $PrivilegedReport -NoTypeInformation -Encoding UTF8
}

# ============================================================
# GENERATE SUMMARY
# ============================================================
$TotalGroups     = $Groups.Count
$TotalEmpty      = $EmptyGroups.Count
$TotalPrivMembers = ($PrivilegedMembers | Where-Object { $_.ObjectType -eq "User" } | 
    Select-Object SamAccountName -Unique).Count

$Summary = @"
============================================
  AD GROUP MEMBERSHIP AUDIT SUMMARY
  Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
============================================

Total Groups Audited          : $TotalGroups
Empty Groups                  : $TotalEmpty
Users in Privileged Groups    : $TotalPrivMembers

--- Privileged Group Membership ---
$( foreach ($PG in $PrivilegedGroups) {
    $Count = ($AllMemberships | Where-Object { $_.GroupName -eq $PG -and $_.ObjectType -eq "User" }).Count
    "  $PG : $Count member(s)"
} )

--- Empty Groups ---
$( if ($EmptyGroups.Count -gt 0) { ($EmptyGroups | ForEach-Object { "  $_" }) -join "`n" } else { "  None found" } )

--- Files Exported ---
  Membership Report  : $MembershipReport
  Privileged Report  : $PrivilegedReport
  Summary            : $SummaryReport
"@

$Summary | Out-File -FilePath $SummaryReport -Encoding UTF8
Write-Host "`n$Summary" -ForegroundColor White
